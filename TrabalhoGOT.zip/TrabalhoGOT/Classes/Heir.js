"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Heir = void 0;
var Heir = /** @class */ (function () {
    function Heir(age, heirPos, name) {
        this.age = age;
        this.heirPos = heirPos;
        this.name = name;
    }
    return Heir;
}());
exports.Heir = Heir;
