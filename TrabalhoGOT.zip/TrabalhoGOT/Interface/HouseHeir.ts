export interface HouseHeir{
    name: string;
    age: number;
    heirPos: number;
}