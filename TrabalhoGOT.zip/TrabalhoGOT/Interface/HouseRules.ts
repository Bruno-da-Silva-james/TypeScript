import { NobleHouse } from "../Classes/NobleHouse";

export interface HouseRules extends NobleHouse{
    
}